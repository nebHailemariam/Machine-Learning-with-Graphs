TASK_CLASSIFY = "classify"
TASK_LINK_PRED = "link_pred"
TASK_GRAPH_CLASSIFICATION = "graph_classification"