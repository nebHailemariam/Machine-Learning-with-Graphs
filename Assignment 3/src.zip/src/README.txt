# README

## Machine Learning with Graphs

Assignment 3

## Description

This is my solution to the assignment of PageRank.

## Getting Started

### Prerequisites

The code was originally written in Python 3.8. Run using the same version if you face a problem.