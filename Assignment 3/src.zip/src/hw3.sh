#!/bin/bash

python3 train.py
python3 predict.py