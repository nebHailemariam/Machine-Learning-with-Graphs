import numpy as np

rank = np.load("rank.npy")

print(rank.shape)
